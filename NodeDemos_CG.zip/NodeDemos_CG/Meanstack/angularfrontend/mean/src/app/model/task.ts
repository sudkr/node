export class Task {
    _id?: number;
   name: string;
   quality: string;
   
}