var express = require('express');
var router = express.Router();
const item = require('./item')
router.get('/', (req, res) => {
    res.send('i am from different routes');
});

router.get('/item', (req,res, next) => {
    item.find(function (err,items) {
     if (err) {
    res.json(err);
    }
    else {
    res.json(items);
    console.log(items);
    }
    });
    });


router.get('/item/:itemname',
function(req,res){

    console.log('Get  all item By itemname');

    item.find({"itemname":req.params.itemname}).exec(function(err,itembyname){

if(err){

     console.log('Error in getting item'+err);
}else{
      res.json(itembyname);
      
}
    });
});





// router.delete("/item/:itemname", (req, res) => {
//   //deleting data
//   item.remove({ itemname: req.params.itemname }, function(err, result) {
//     if (err) {
//       res.json(err);
//     } else {
//       res.json(result);
//     }
//   });
// });

router.delete('/item/:id',(req,res)=>

{
//deleting data
item.remove({_id:req.params.id},
    function(err,result){
        if(err){
        res.json(err);    
        }
    else {
        res.json(result);
    }
    }
    );
});



router.put('/item/:id', (req, res, next) => {

    //updating data

    Item.findOneAndUpdate({ _id: req.params.id },
         { $set: {
              itemnames:req.body.itemnames,
               itemquantitys:
                    req.body.itemquantitys,

                itemboughts:
                    req.body.itemboughts
} }, function (err,result) {
 if (err) {  res.json(err);

            }
else {
 // res.json(result);
 res.json({ msg: 'Item has been updated successfully'
                })
 }
})

});


router.post('/item', (req, res, next) => {
    const newitem = new item(
        {
            name:req.body.name,
            quality:req.body.quality,
            itembought:req.body.itembought
        });// this item close

newitem.save((err, item) => {
    if (err) {
        res.json(err);
    }
    else {
        res.json({ msg: 'inserted' })
    }
});
});//port close
module.exports = router;
