const mongoose = require('mongoose');
const itemsschema = mongoose.Schema(
    {
        name: {
            type:String,
            required:false
        },
        quality: {
            type:Number,
            required:false
        },
        itembought:{
        type:Boolean,
        required:false   
        },
    });
    const items = module.exports = mongoose.model('items',itemsschema);