var express = require('express');
var mongoose = require ('mongoose');
const routes = require('../router/router');
var cors= require('cors');

mongoose.connect('mongodb://localhost:27017/mydb',{ useNewUrlParser: true });
mongoose.connection.on('connected',()=>
{
    console.log('MongoDB is connected in port no 27017');
})

var app = express();
app.get('/',(req,res)=>
{
    res.send('Hello From Root Path');
});
app.use(express.json());

//add a middleware to configure the routes
app.use(cors());
app.use('/api',routes);



const port = 5000;
app.listen(port,function()
{
    console.log('Server started on port number' , port);
});