import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Item } from '../model/item';
@Injectable({
  providedIn: 'root'
})
export class ItemServiceService {
  constructor(private http:HttpClient) { }
getshoppingitem(){
return this.http.get("http://localhost:5000/api/items")
}
addshoppingitem(item:Item){
     return this.http.post("http://localhost:5000/api/item",item)
 }

 updateshoppingitem(newItem)
{
return this.http.put('http://localhost:5000/api/item/'+newItem._id,newItem);
}

//  deleteshoppingItem(id:number){
//   return this.http.post("http://localhost:5000/api/item",id)
//  }
deleteshoppingItem(_id:number){

  return this.http.delete("http://localhost:5000/api/item"+"/"+_id)
  
  }

}
