export class Item{
    _id?:number;
    itemname:string;
    itemquantity:number;
    itembought:boolean;
}