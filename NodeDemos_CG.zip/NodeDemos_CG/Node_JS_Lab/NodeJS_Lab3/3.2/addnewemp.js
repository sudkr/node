var mongodb = require('mongodb');

var mongoclient1 = mongodb.MongoClient;

var url = 'mongodb://localhost:27017/employee';

//connect to mongoclient
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log("connection established" + url);

        //Creating database
        var db = client.db('employee');

        //creating collection
        var collection = db.collection('employeescol');


        //find all employee details
        collection.insert([{
            "empId": 1007,
            "empName": "Derena",
            "empSalary": 5000,
            "empAddress": {
                "city": "San Tiego",
                "state": "California"
              }
            }], function (err, res) {
            if (err) {
                console.log(err);
            }
            else {
                console.log('data is  ', res);
            }
        });
    }
});