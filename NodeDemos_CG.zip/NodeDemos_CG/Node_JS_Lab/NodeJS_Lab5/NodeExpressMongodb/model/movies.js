var mong=require('mongoose');


const moviesSchema=new mong.Schema({

    name:{
        type:String,
        required:true
    },
    rating:{
        type:Number,    
        required:true
    },
    dgenre:{
        type:String,
        required:true
    }
});

const movies=module.exports=mong.model('movies',moviesSchema)