var Emp = require('./lib/employee');

empOne=new Emp.data(1001,'Rahul',8888.88);
empTwo=new Emp.data(1002,'Kumar',8888.88);
Emp.set(empOne);
Emp.set(empTwo);
Emp.get();

