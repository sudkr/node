import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddUserComponent } from './component/add-user/add-user.component';
import { TodoListComponent } from './component/todo-list/todo-list.component';
import { EditUserComponent } from './component/edit-user/edit-user.component';

const routes: Routes = [
  { path: 'add', component: AddUserComponent},
  { path: 'todo-list', component: TodoListComponent},
  { path:'edit',component:EditUserComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
