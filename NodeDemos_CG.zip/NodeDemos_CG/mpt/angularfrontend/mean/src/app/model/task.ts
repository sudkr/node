export class Task {
    _id?: string;
   name: string;
    quantity: string;
}
