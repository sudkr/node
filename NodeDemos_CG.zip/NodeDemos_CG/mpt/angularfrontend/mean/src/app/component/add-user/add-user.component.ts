import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TaskService } from 'src/app/service/task.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;
  constructor(private formbuilder: FormBuilder,
    private router: Router,
    private taskservice: TaskService) { }

  ngOnInit() {
    this.addForm = this.formbuilder.group({
      id: [],
      name: ['', Validators.required], 
      quantity: ['', Validators.required]
    });
  }
  goback(){
    this.router.navigate(['todo-list']);
  }
  onSubmit(){
    this.submitted=true;
    if(this.addForm.invalid){
      return true;
    }
    this.taskservice.createtask(this.addForm.value).subscribe(data=>{
      alert(this.addForm.value.name +'Record Added..!')
      this.taskservice.getTasks().subscribe();
      this.router.navigate(['todo-list']);});
      
  }

}
