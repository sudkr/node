import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Task } from 'src/app/model/task';
import { Router } from '@angular/router';
import { TaskService } from 'src/app/service/task.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  item: Task[];
  constructor(private router: Router,
    private taskservice: TaskService,
    private formBuilder: FormBuilder) { }

  ngOnInit() {
    
   
    this.editForm = this.formBuilder.group({
      _id: [],
      name: ['', Validators.required] ,
      quantity: ['', Validators.required],
      __v:['']
    });

     let id = localStorage.getItem("id")
    this.taskservice.getTasksById(id).subscribe(data => {
      this.editForm.setValue(data)
    })
  }
  
  edit() {
    this.taskservice.edittask(this.editForm.value).subscribe(data => { });

    alert('Record Updated!');

    location.reload();

  }
  goback(){
    this.router.navigate(['todo-list']);
  }

}
