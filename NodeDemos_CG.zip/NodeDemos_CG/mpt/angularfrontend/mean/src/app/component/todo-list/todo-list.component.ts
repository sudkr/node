import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Task } from 'src/app/model/task';
import { TaskService } from 'src/app/service/task.service';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})
export class TodoListComponent implements OnInit {
  tasks:Task[];
  constructor(private taskservice: TaskService, 
    private router: Router) { }

  ngOnInit() {
   
    this.taskservice.getTasks().subscribe(displayList => this.tasks = displayList)
  }
  
  deletetask(task: Task):void {
    let result = confirm("Do you really want to delete the task?")
    if(result){
      this.taskservice.deletetask(task._id).subscribe(data=>{
        this.tasks =this.tasks.filter(u=> u!== task);
      });
    }    
  }
  addtask():void {
      this.router.navigate(['add']);
  }

  edittask(task: Task):void{
    confirm("Do you really want to Edit the task?")
    localStorage.removeItem("id")
    localStorage.setItem("id", task._id)

    this.router.navigate(['edit']);
    
  } 
  
  
}
  
