var express =require('express');
var mongoose = require('mongoose');
//import the router file 
const route = require('./route/router');
var cors=require('cors');

 mongoose.connect('mongodb://localhost:27017/mycgmean');
 mongoose.connection.on('connected',()=>
 {
 console.log('Mongodb connected on port no 27017');
 }  
 );

var app=  express();
app.get('/',(req,res)=>
{
   res.send('Hello from Root path');
   
});
//add an middle ware to parse the data in json
app.use(express.json());
app.use(cors());
//add an middle ware to configure the routes
app.use('/api',route);


const port =5000;
app.listen(port,function()
{
    console.log('Server started on port number '+port);
})

