var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/mobile';
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log('Connection established' + url);
        var db = client.db('mobile');
        var collection = db.collection('mobiledata');
        var mobone = { mobid: 100, mobilename: 'samsung', mobilecost: 1000 };
        var mobtwo = { mobid: 200, mobilename: 'apple', mobilecost: 2000 };
        
        collection.update( mobtwo,{$set:{mobilename:"redmi"}}, function (err, data)
        //collection.update()
        {
            if (err) {
                console.log(err);
            }
            else {
                console.log('number of rows inserted' + data);
                //console.log('%s',res);
            }

            client.close()

        });

    }
});