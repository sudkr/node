const fsobj=require('fs');
fsobj.readFile('input.txt',function(err,data)//asyc
{
    if(err){
        console.log("Problem in reading");

    }
    else{
        console.log('reading');
    }

       
    
});console.log('program ended');
