const
    fs = require('fs');



//write in file



let
    student = [{



        name:
            'rashmi ',



        age:
            25,



        gender:
            'female'







    }]



let
    data = JSON.stringify(student);



fs.writeFile('student1.json',
    data, (err)=> {



        if (err)



            throw err;



        else



            console.log('data write into the file')



    });











//appending in the file







let
    student2 = {



        name:
            'ali raj',



        age:
            9,



        gender:
            'male'







    }







console.log('this is the end of the program')







//append







fs.readFile('student1.json', (er,data) => {



    if (er)



        throw er;



    else {

        let
            read;



        read =
            JSON.parse(data);





        read.push(student2)





        read =
            JSON.stringify(read)



        fs.writeFile('student1.json',
            read, (err)=> {



                if (err)



                    throwerr;



                else



                    console.log('data appended into the file')



            });





    }



})




