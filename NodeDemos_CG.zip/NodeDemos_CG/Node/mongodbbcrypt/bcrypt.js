var bcrypt = require('bcrypt');



var hash =bcrypt.hashSync('rashmi',bcrypt.genSaltSync(12));

console.log(hash);



var v=bcrypt.compareSync('rashmi',hash);

console.log("returns " +v);

var v =bcrypt.compareSync('rashmii',hash);

console.log("returns " +v);

//asynchro

bcrypt.hash('rashmi',bcrypt.genSaltSync(10),function(err,hash){

    bcrypt.compare('rashmi',hash,function(err,res){
    
    //should return true
    
    console.log('true');
    
    
    });
    
    });