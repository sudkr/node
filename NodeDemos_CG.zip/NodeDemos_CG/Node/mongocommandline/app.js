var mongodb =require('mongodb');

var mongoclient1=mongodb.MongoClient;

var url = 'mongodb://localhost:27017/shopping';

mongoclient1.connect(url,function(err,client){

    if(err){

        console.log(err);

    }

    else{

        console.log('connention established '+url);




        var db=client.db('shopping');

        var collection=db.collection('usercart');

        collection.find({
            $and: [{"username": "Sachin"},
            {"password":"Sachin"}
        ]
        }).toArray((err,docs)=>{
            if(err){
                console.log(err);
            }
            else{
                if(docs.length == 0){
                    console.log("User doesnot exist");
                }
                else{
                    console.log("USer Exist");
                }
            }
        })

        let user1={        

        "username":"Sachin","password":"Sachin",     

        "email":"Sachin@gmail.com",

        "carts":[

        {"id":1,"name":"IPhone","cost":98989,"quantity":2},

        {"id":2,"name":"EarPhone","cost":9898,"quantity":2}           

        ],

        "orders":[

        {"orderid":1000,"orderdate":"19-08-2018",status:"delivered"},

        {"orderid":1001,"orderdate":"29-08-2018","status":"pending"}

        ],     

        "orderItem":[

        {"orderItemId":10001,"name":"IPhone",cost:98989,"quantity":2,"orderid":1000},

        {"orderItemId":10002,"name":"EarPhone",cost:9898,"quantity":2,"orderid":1000},     

        {"orderItemId":10003,"name":"Chair",cost:1000,"quantity":1,"orderid":1001},

        {"orderItemId":10004,"name":"Table",cost:2000,"quantity":1,"orderid":1001}

        ]

        }

        collection.insert(user1,function(err,data){

            if(err){

                console.log(err);

            }

            else

            {

                console.log('number of rows inserted',data)

            }   

        client.close(); 

        })

    }

})