
module.exports.hello={
    getData:"hello",
    getLogin:function(){
        console.log("in login function");

    }
}