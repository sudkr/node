var obj=require("./mode1.js")
console.log(obj.hello.getData);
(obj.hello.getLogin());