const mongodb=require('mongodb');
const MongoClient=mongodb.MongoClient;
var url = 'mongodb://localhost:27017/colleges';
MongoClient.connect(url,function(err,client){
  if(err){
    console.log(err);
  }else{
    console.log('Connection establish....'+url);
    var db=client.db('colleges');
    var collection=db.collection('colleges');

    collection.update({'collegeId':1002},{$set:{'collegeName':'KLSGIT 7','state':'karnataka'}},function(req,res){
    if(err){
      console.log(err);
    }else{
      console.log('Updated Data...'+res);
    }
  });
}
});