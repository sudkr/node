var ee = new EventEmitter();
var timer;
ee.once("start",(startPos)=>{
    var i=startPos;
    console.log("Starting timer");
    timer=setInterval(()=>{
        console.log(i);
    })
})
