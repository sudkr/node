import { Component, OnInit } from '@angular/core';
import { Item } from './model/item';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ItemService } from './service/item.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  items:Item[];
addForm:FormGroup
  constructor(private itemservice:ItemService,
    private formbuilder:FormBuilder){
  }
  ngOnInit(){
        this.addForm=this.formbuilder.group({
          itemname:['',Validators.required],
          itemquantity:['',Validators.required],
          itembought:['',Validators.required]
     
        })
}
  title = 'AngularFrontend';

  addshoppingitem(){
    this.itemservice.addshoppingitem(this.addForm.value).subscribe(data=>{})
    console.log(this.addForm.value)
  }

}