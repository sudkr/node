import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Item } from '../model/item';

@Injectable({
  providedIn: 'root'
})
export class ItemService {
// baseurl="http://localhost:5000/api/item"
// url="http://localhost:5000/api/items"

constructor(private http:HttpClient) { }

getshoppingitems(){
return this.http.get('http://localhost:5000/api/items');
}
addshoppingitem(items:Item){
  return this.http.post('http://localhost:5000/api/item',items);

}
deleteshoppingItem(id){
  return this.http.delete('http://localhost:5000/api/item/'+id);
}
}
