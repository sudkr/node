var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/college';
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log('Connection established' + url);
        var db = client.db('college');
        var db = client.db('college');
        var collection = db.collection('collegedata');
        
        
        collection.update( mobtwo,{$set:{collegeone:"IIT"}}, function (err, data)
      

        //collection.update()
        {
            if (err) {
                console.log(err);
            }
            else {
                console.log('number of rows inserted' + data);
                //console.log('%s',res);
            }

            client.close()

        });

    }
});