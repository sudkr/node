var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/college';
mongoclient1.connect(url, function (err, client) {
    if (err) {
        console.log(err);
    }
    else {
        console.log('Connection established' + url);
        var db = client.db('college');
        var collection = db.collection('collegedata');
        var collegeone = { collegeid: 1004, collegename: 'IIT', collegestate: "Delhi" };
        var collegetwo = { collegeid: 1002, mobilename: 'BIT Mesra', collegestate: "Ranchi" };
        var collegethree = { collegeid: 1003, collegename: 'BITS', collegestate: "Pilani" };
        var collegefour = { collegeid: 1001, mobilename: 'Niit', collegestate: "Suratkal" };
        var collegefive = { collegeid: 1005, mobilename: 'REC', collegestate: "Kolkata" };
       
        collection.remove(collegeone, collegetwo,collegethree,collegefour,collegefive, function (err, data)
        
        {
            if (err) {
                console.log(err);
            }
            else {
                console.log('number of rows inserted' + data);
                //console.log('%s',res);
            }

            client.close()

        });

    }
});