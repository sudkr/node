var mongodb = require('mongodb');
var Mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/colleges';
Mongoclient1.connect(url, function (err, client) {
  if (err) {
    console.log(err);
  } else {
    console.log('Connection established....' + url);
    var db = client.db('colleges');
    var collection = db.collection('colleges');
    var colleges =
      [
        {
          "collegeId": 1004,
          "collegeName": "IIT",
          "state": "Delhi"

        },
        {
          "collegeId": 1002,
          "collegeName": "BIT Mesra",
          "state": "Ranchi"
        },
        {
          "collegeId": 1003,
          "collegeName": "BITS",
          "state": "Pilani"
        },
        {
          "collegeId": 1001,
          "collegeName": "Niit",
          "state": "Suratkal"
        },
        {
          "collegeId": 1005,
          "collegeName": "REC",
          "state": "Kolkata"
        }
      ]

    collection.insert(colleges, function (err, data) {
      if (err) {
        console.log(err);
      }
      else {
        console.log('number of rows inserted', data);
      }
    })
  }
  client.close();
});