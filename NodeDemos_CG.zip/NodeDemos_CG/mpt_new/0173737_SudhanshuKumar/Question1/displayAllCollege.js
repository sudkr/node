var mongodb = require('mongodb');
var mongoclient1 = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/colleges';
mongoclient1.connect(url, function (err, client) {
  if (err) {
    console.log(err);
  } else {
    console.log('Connection established....' + url);
    var db = client.db('colleges');
    var collection = db.collection("colleges");

    collection.find({}).toArray(function (err, data) {
      if (err) console.log(err);
      else {
        console.log(data);
      }
    });
  }
  client.close();
});