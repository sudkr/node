const express = require('express');

const path = require('path');
//initialize the app object
const app = express();

//load the view engilne 
app.set('views', path.join(__dirname, "views"));
console.log(__dirname)
app.set("view engine", "pug");
//defining the routes
app.get('/ShowProductInfo', function (req, res) {
    let emp = [
        {
            prodid: 1001,
            prodName: 'TV',
            prodPrice: 45000,

        },
        {
            prodid: 1002,
            prodName: 'Mobile',
            prodPrice: 34000,

        },
        {
            prodid: 1003,
            prodName: 'Laptop',
            prodPrice: 67000,

        }
    ];
    res.render('index', {
        title: 'This is Capgemini L&D',
        empData: emp
    }); //render close
}) //get close
//create another route as ShowProductInfo
app.get('/', function (req, res) {
    res.render('ShowProductInfo', {
        mydata: 'This is Capgemini L&D'
    });
});
app.listen(3000, function () {
    console.log('Server is started on port 3000');
})