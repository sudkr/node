import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddUserComponent } from './component/add-user/add-user.component';
import { TodoListComponent } from './component/todo-list/todo-list.component';

const routes: Routes = [
  { path: 'add', component: AddUserComponent},
  { path: 'todo-list', component: TodoListComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
