export class Task {
    id: number;
    itemname: string;
    itemquantity: string;
}